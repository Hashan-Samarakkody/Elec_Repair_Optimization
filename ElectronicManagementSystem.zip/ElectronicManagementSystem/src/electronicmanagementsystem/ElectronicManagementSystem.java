/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package electronicmanagementsystem;

/**
 *
 * @author DELL
 */
public class ElectronicManagementSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Login_page page1 = new Login_page();
        page1.setVisible(true);
    }
    
}
