/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electronicmanagementsystem;

import javax.swing.JOptionPane;

/**
 *
 * @author senud
 */
public abstract class Person {

    private String title;
    private String firstName;
    private String lastName;

    // Constructor
    public Person(String title, String firstName, String lastName) {
        this.setTitle(title);
        this.setFirstName(firstName);
        this.setLastName(lastName);
    }

    // Common getters and setters
    public String getTitle() {
        if (title == null || title.trim().isEmpty()) {
            
            throw new IllegalArgumentException("Title cannot be empty or null.");
        }
        // Check if the title is one of the allowed values
        String trimmedTitle = title.trim();
        if (!trimmedTitle.equals("Mr") && !trimmedTitle.equals("Miss") && !trimmedTitle.equals("Mrs") && !trimmedTitle.equals("Rev")) {
           
            throw new IllegalArgumentException("Invalid title. Allowed titles are: Mr, Miss, Mrs, Rev.");
        }
        return title;
    }

    public void setTitle(String title) {
        if (title == null || title.trim().isEmpty()) {
            
            throw new IllegalArgumentException("Title cannot be empty or null.");
        }
        // Check if the title is one of the allowed values
        String trimmedTitle = title.trim();
        if (!trimmedTitle.equals("Mr") && !trimmedTitle.equals("Miss") && !trimmedTitle.equals("Mrs") && !trimmedTitle.equals("Rev")) {
            
            throw new IllegalArgumentException("Invalid title. Allowed titles are: Mr, Miss, Mrs, Rev.");
        }
        this.title = trimmedTitle;
    }

    public String getFirstName() {
        if (firstName == null || firstName.trim().isEmpty()) {
            //JOptionPane.showMessageDialog(null, "First name cannot be empty or null.", "Error", JOptionPane.ERROR_MESSAGE);
            throw new IllegalArgumentException("First name cannot be empty or null.");
        }
        // Check if the first name contains only letters
        if (!firstName.matches("[a-zA-Z]+")) {
            //JOptionPane.showMessageDialog(null, "First name can only contain letters.", "Error", JOptionPane.ERROR_MESSAGE);
            throw new IllegalArgumentException("First name can only contain letters.");
        }
        return firstName;
    }

    public void setFirstName(String firstName) {
        
        this.firstName = firstName.trim();
    }

    public String getLastName() {
        if (lastName == null || lastName.trim().isEmpty()) {
            //JOptionPane.showMessageDialog(null, "Last name cannot be empty or null.", "Error", JOptionPane.ERROR_MESSAGE);
            throw new IllegalArgumentException("Last name cannot be empty or null.");
        }
        // Check if the last name contains only letters
        if (!lastName.matches("[a-zA-Z]+")) {
            //JOptionPane.showMessageDialog(null, "Last name can only contain letters.", "Error", JOptionPane.ERROR_MESSAGE);
            throw new IllegalArgumentException("Last name can only contain letters.");
        }
        return lastName;
    }

    public void setLastName(String lastName) {
        
        this.lastName = lastName.trim();
    }

    // Abstract method for getting full details
    public abstract String getFullDetails();
}
