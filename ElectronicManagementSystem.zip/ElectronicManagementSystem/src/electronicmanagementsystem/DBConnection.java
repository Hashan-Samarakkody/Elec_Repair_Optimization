/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electronicmanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author hashan
 */
public class DBConnection {

    //Variables declaration
    public Connection conn;
    private final String url = "jdbc:mysql://localhost:3306/repair_system2";
    private final String user = "root";
    private final String password = "ThHiuok#21";

    public Connection provideConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.conn
                    = DriverManager.getConnection(
                            url,
                            user,
                            password
                    );
            
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null,"Driver Not Found!");
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Connection Failed!");
            System.out.println(e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Unknown Error Occurred !");
            System.out.println(e.getMessage());
        }
        return conn;
    }
}
